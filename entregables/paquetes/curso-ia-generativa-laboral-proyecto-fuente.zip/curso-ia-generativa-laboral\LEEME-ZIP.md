﻿# Proyecto fuente · IA generativa para entornos laborales

Este zip trae la investigación, el contenido base, las fuentes de los quiz, las infografías y los casos, los scripts (Node 18 o más,
sin dependencias) y las skills de Claude (.claude/skills/).

**No incluye la planilla de origen** (data/planilla/ ni data/curso.json), porque es de otra persona. Para regenerar el curso:
1. descarga tu planilla como .xlsx y conviértela con `node scripts/xlsx2tsv.mjs` en data/planilla/;
2. corre `node scripts/importar-planilla.mjs`, que crea data/curso.json;
3. sigue docs/PROCESO.md.

